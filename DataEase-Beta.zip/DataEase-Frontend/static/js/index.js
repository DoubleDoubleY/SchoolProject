var server_host = 'http://192.168.1.104:8080/'

$(function() {
  setTables();

  $('#btn_select').click(function() {
    loadTable();

    // 1.初始化Table
    var oTable = new tableInit();
    oTable.Init();

    // 2.初始化Button的点击事件
    var oButtonInit = new buttonInit();
    oButtonInit.Init();

    console.log($('#table').bootstrapTable('getOptions'));

  });


});

function setTables() {
  $.ajax({
    type: 'POST',
    url: server_host + 'tables',
    dataType: 'json',
    data: JSON.stringify({'cmd': 'show'}),
    success: function(data) {
      var str = new String();
      data.data.forEach(function(e) {
        str += '<option>' + e.name + '</option>';
      })
      $('#table_select').html(str);
    },
    error: function(xhr, error_msg, error_thrown) {
      console.log(
          '[' + error_msg + ' ' + xhr.status + ']' +
          ' : ' + xhr.getResponseHeader('content-type'));
      alert(
          '[' + error_msg + ' ' + xhr.status + ']' +
          ' : ' + xhr.getResponseHeader('content-type'));
    }
  });
}

function loadTable() {
  var str = new String();
  str += '<div id="toolbar" class="btn-group">' +
      '<button id="btn_add" type="button" class="btn btn-default"><span class="glyphicon glyphicon-plus" aria-hidden="true"></span>新增</button>' +
      '<button id="btn_edit" type="button" class="btn btn-default"><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span>修改</button>' +
      '<button id="btn_delete" type="button" class="btn btn-default"><span class="glyphicon glyphicon-remove" aria-hidden="true"></span>删除</button>' +
      '</div><table id="table"></table>';
  $('#table_load').html(str);
}

var tableInit = function() {
  var oTableInit = new Object();
  var oSubTableInit = new Object();
  var relation = getRela($('#table_select').val());
  console.log(relation);
  //   var relationable = false;
  //   if (relation.rela_table != '') {
  //     relationable = true;
  // }
  oTableInit.Init = function() {
    $('#table').bootstrapTable({
      // url: 'http://192.168.1.104:8080',  //请求后台的URL（*）
      method: 'post',       //请求方式（*）
      toolbar: '#toolbar',  //工具按钮用哪个容器
      striped: true,        //是否显示行间隔色
      cache:
          false,                            //是否使用缓存，默认为true，所以一般情况下需要设置一下这个属性（*）
      pagination: true,                     //是否显示分页（*）
      sortable: true,                       //是否启用排序
      sortOrder: 'asc',                     //排序方式
      queryParams: oTableInit.queryParams,  //传递参数（*）
      sidePagination:
          'client',  //分页方式：client客户端分页，server服务端分页（*）
      pageNumber: 1,                //初始化加载第一页，默认第一页
      pageSize: 10,                 //每页的记录行数（*）
      pageList: [10, 25, 50, 100],  //可供选择的每页的行数（*）
      search:
          true,  //是否显示表格搜索，此搜索是客户端搜索，不会进服务端，所以，个人感觉意义不大
      strictSearch: true,
      showColumns: true,       //是否显示所有的列
      showRefresh: false,      //是否显示刷新按钮
      minimumCountColumns: 2,  //最少允许的列数
      clickToSelect: true,     //是否启用点击选中行
      height:
          500,           //行高，如果没有设置height属性，表格自动根据记录条数觉得表格高度
      uniqueId: 'id',    //每一行的唯一标识，一般为主键列
      showToggle: true,  //是否显示详细视图和列表视图的切换按钮
      cardView: false,   //是否显示详细视图
      detailView: relation.relationable,  //是否显示父子表
      columns: getColumns($('#table_select').val()),
      data: getData($('#table_select').val()),
      onExpandRow: function(index, row, $detail) {
        oSubTableInit.InitSubTable(index, row, $detail);
      }
    });
  };

  oSubTableInit.InitSubTable = function(index, row, $detail) {
    // console.log(row);
    relation['value'] = row[relation.field];
    var parentid = row.MENU_ID;
    var sub_table = $detail.html('<table></table>').find('table');
    $(sub_table).bootstrapTable({
      //   url: '',
      method: 'post',
      sortable: false,
      queryParams: {strParentID: parentid},
      ajaxOptions: {strParentID: parentid},
      clickToSelect: true,
      detailView: false,
      uniqueId: 'MENU_ID',
      pageSize: 10,
      pageList: [10, 25],
      columns: getColumns(relation.rela_table),
      data: getData(relation.rela_table, relation)
    });
  };

  // console.log($('#table').bootstrapTable('getOptions').columns[0]);

  //得到查询的参数
  oTableInit.queryParams = function(params) {
    var temp = {
      limit: params.limit,    //页面大小
      offset: params.offset,  //页码

    };
    return temp;
  };
  return oTableInit;
};


var buttonInit = function() {
  var oInit = new Object();
  oInit.Init = function() {
    $('#btn_add').click(function() {
      $('#form_add').html(getForm('add'));
      $('#dlg_add').modal();
    });

    $('#submit_add').click(function() {
      var add_form = new Object();
      var cur_table = $('#table_select').val();
      // var objs = $('.add-input');
      // console.log(objs);
      // Object.keys(objs).forEach(function(key) {
      //   add_form[objs[key].id] = objs[key].value;
      // });
      // add_form[id] = '';
      // console.log(add_form);
      // delete add_form.['object HTMLInputElement'];
      //   for (var prop in objs) {
      //     add_form[prop] = objs[prop];
      //   }
      $('.add-input').each(function() {
        // console.log($(this));
        add_form[$(this)[0].id] = $(this)[0].value;
      });
      // console.log(add_form);
      deleteEmptyProperty(add_form);
      // console.log(add_form);
      $.ajax({
        type: 'POST',
        url: server_host + cur_table,
        dataType: 'json',
        data: JSON.stringify({'cmd': 'insert', 'data': [add_form]}),
        success: function(data) {
          // console.log(data);
          var new_index = $('#table').bootstrapTable('getData').length;
          console.log(new_index);
          $('#table').bootstrapTable(
              'insertRow', {index: new_index, row: data.data[0]});
        },
        error: function(xhr, error_msg, error_thrown) {
          console.log(
              '[' + error_msg + ' ' + xhr.status + ']' +
              ' : ' + xhr.getResponseHeader('content-type'));
          alert(
              '[' + error_msg + ' ' + xhr.status + ']' +
              ' : ' + xhr.getResponseHeader('content-type'));
        }
      });
    })

    $('#btn_edit').click(function() {
      $('#form_edit').html(getForm('edit'));
      var row = $('#table').bootstrapTable('getSelections');
      //   console.log(row);
      var edit_form = new Object();
      if (row.length != 1) {
        alert('请选择一行以执行修改操作!');
      } else {
        $('#dlg_edit').modal();
        console.log(row[0]);
        for (var prop in row[0]) {
          console.log(prop, row[0][prop]);
          $('.edit-input' +
            '#' + prop)
              .val(row[0][prop]);
        }
      }
    });

    $('#submit_edit').click(function() {
      var edit_form = new Object();
      var cur_table = $('#table_select').val();
      // var objs = $('.edit-input');
      // Object.keys(objs).forEach(function(key) {
      //   edit_form[objs[key].id] = objs[key].value;
      // });
      $('.edit-input').each(function() {
        edit_form[$(this)[0].id] = $(this)[0].value;
      });
      // deleteEmptyProperty(edit_form);
      // console.log(edit_form);
      $.ajax({
        type: 'POST',
        url: server_host + cur_table,
        dataType: 'json',
        data: JSON.stringify({'cmd': 'update', 'data': [edit_form]}),
        success: function(data) {
          $('#table').bootstrapTable(
              'remove', {field: 'id', values: [data.data[0].id]});
          var new_index = $('#table').bootstrapTable('getData').length;
          console.log(new_index);
          $('#table').bootstrapTable(
              'insertRow', {index: new_index, row: data.data[0]});
          $('#btn_select').click();
          // $('#table').bootstrapTable(
          //     'updateRow', {index: 6, row: data.data[0]});
        },
        error: function(xhr, error_msg, error_thrown) {
          console.log(
              '[' + error_msg + ' ' + xhr.status + ']' +
              ' : ' + xhr.getResponseHeader('content-type'));
          alert(
              '[' + error_msg + ' ' + xhr.status + ']' +
              ' : ' + xhr.getResponseHeader('content-type'));
        }
      });
    });

    $('#btn_delete').click(function() {
      if ($('#table').bootstrapTable('getSelections').length == 0) {
        alert('请至少选择一行再执行删除操作！');
      } else {
        $('#dlg_delete').modal();
      }
    });

    $('#submit_delete').click(function() {
      var rows_id = new Array();
      var cur_table = $('#table_select').val();
      var rows = $('#table').bootstrapTable('getSelections');
      console.log(rows);

      rows.forEach(function(e) {
        delete e[0];
        rows_id.push(e.id);
      })
      console.log(rows_id);
      $.ajax({
        type: 'POST',
        url: server_host + cur_table,
        dataType: 'json',
        data: JSON.stringify({'cmd': 'delete', 'data': rows}),
        success: function(data) {
          $('#table').bootstrapTable('remove', {field: 'id', values: rows_id});
        },
        error: function(xhr, error_msg, error_thrown) {
          console.log(
              '[' + error_msg + ' ' + xhr.status + ']' +
              ' : ' + xhr.getResponseHeader('content-type'));
          alert(
              '[' + error_msg + ' ' + xhr.status + ']' +
              ' : ' + xhr.getResponseHeader('content-type'));
        }
      });
    })
  };

  return oInit;
};

function getForm(type) {
  var str = new String();
  columns = $('#table').bootstrapTable('getOptions').columns[0];
  for (var i = 1; i < columns.length; i++) {
    str += '<div class="form-group">' +
        '<label for="' + columns[i].title +
        '" class="col-sm-2 control-label">' + columns[i].title + ':</label>' +
        '<div class="col-sm-10">' +
        '<input class="form-control ' + type + '-input" id="' +
        columns[i].title + '" type="text">' +
        '</div>' +
        '</div>';
  }
  return str;
}

function getColumns(table_name) {
  var new_columns = new Array();
  new_columns.push({checkbox: true});
  // new_columns.push({
  //   field: 'index',
  //   title: 'index',
  //   align: 'center',
  //   valign: 'middle',
  //   hide: false
  // });
  $.ajax({
    url: server_host + table_name,
    type: 'post',
    dataType: 'json',
    async: false,
    data: JSON.stringify({'cmd': 'describe'}),
    success: function(ret_value) {
      var arr = ret_value.data;
      arr.forEach(function(e) {
        new_columns.push({
          field: e.field,
          title: e.field,
          align: 'center',
          valign: 'middle',
          sortable: true
        });
        // if (e.field == 'id') {
        //   new_columns.push({
        //     field: e.field,
        //     title: e.field,
        //     align: 'center',
        //     valign: 'middle',
        //     sortable: true
        //   });
        // } else {
        //   new_columns.push({
        //     field: e.field,
        //     title: e.field,
        //     align: 'center',
        //     valign: 'middle'
        //   });
        // }
      });
    },
    error: function(xhr, error_msg, error_thrown) {
      console.log(
          '[' + error_msg + ' ' + xhr.status + ']' +
          ' : ' + xhr.getResponseHeader('content-type'));
      alert(
          '[' + error_msg + ' ' + xhr.status + ']' +
          ' : ' + xhr.getResponseHeader('content-type'));
    }
  });
  return new_columns;
}

function getRela(table_name) {
  var relation = new Object();
  $.ajax({
    url: server_host + table_name,
    type: 'post',
    dataType: 'json',
    async: false,
    data: JSON.stringify({'cmd': 'describe'}),
    success: function(ret_value) {
      var arr = ret_value.data;
      arr.forEach(function(e) {
        if (e.foreign_key != '') {
          relation['field'] = e.field;
          relation['rela_table'] = e.foreign_key;
          relation['relationable'] = true;
        }
      });
    },
    error: function(xhr, error_msg, error_thrown) {
      console.log(
          '[' + error_msg + ' ' + xhr.status + ']' +
          ' : ' + xhr.getResponseHeader('content-type'));
      alert(
          '[' + error_msg + ' ' + xhr.status + ']' +
          ' : ' + xhr.getResponseHeader('content-type'));
    }
  });
  return relation;
}

function getData(table_name, relation) {
  var data_array = new Array();
  var table_columns = new Array();
  var get_columns = new Object();
  table_columns = getColumns(table_name);
  for (var i = 1; i < table_columns.length; ++i) {
    get_columns[table_columns[i].field] = '';
  }
  if (relation === undefined) {
  } else {
    get_columns['id'] = relation['value'];
  }
  delete get_columns[undefined];
  $.ajax({
    type: 'POST',
    url: server_host + table_name,
    dataType: 'json',
    async: false,
    data: JSON.stringify({'cmd': 'select', 'data': [get_columns]}),
    success: function(data) {
      // console.log(data);
      // $('#table').bootstrapTable('load', data.data);
      data_array = data.data;
    },
    error: function(xhr, error_msg, error_thrown) {
      console.log(
          '[' + error_msg + ' ' + xhr.status + ']' +
          ' : ' + xhr.getResponseHeader('content-type'));
      alert(
          '[' + error_msg + ' ' + xhr.status + ']' +
          ' : ' + xhr.getResponseHeader('content-type'));
    }
  });
  return data_array;
}

function deleteEmptyProperty(object) {
  for (var i in object) {
    var value = object[i];
    if (typeof value === 'object') {
      if (Array.isArray(value)) {
        if (value.length == 0) {
          delete object[i];
          continue;
        }
      }
      deleteEmptyProperty(value);
      if (isEmpty(value)) {
        delete object[i];
      }
    } else {
      // if (value === '' || value === null || value === undefined) {
      if (value === undefined) {
        delete object[i];
      }
    }
  }
}

function isEmpty(object) {
  for (var name in object) {
    return false;
  }
  return true;
}