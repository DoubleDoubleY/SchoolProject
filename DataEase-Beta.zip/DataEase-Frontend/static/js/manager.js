var server_host = 'http://192.168.1.104:8080/'

$(function() {
  $('#table_select').html(getTables());

  var oButtonInit = new ButtonInit();
  oButtonInit.Init();


});

function getTables() {
  var tables_str = new String();
  $.ajax({
    type: 'POST',
    url: server_host + 'tables',
    dataType: 'json',
    async: false,
    data: JSON.stringify({'cmd': 'show'}),
    success: function(data) {
      data.data.forEach(function(e) {
        tables_str += '<option>' + e.name + '</option>';
      })
    },
    error: function(xhr, error_msg, error_thrown) {
      console.log(
          '[' + error_msg + ' ' + xhr.status + ']' +
          ' : ' + xhr.getResponseHeader('content-type'));
      alert(
          '[' + error_msg + ' ' + xhr.status + ']' +
          ' : ' + xhr.getResponseHeader('content-type'));
    }
  });
  return tables_str;
}

function getTypes() {
  var types_str = new String();
  $.ajax({
    type: 'POST',
    url: server_host + 'data-types',
    dataType: 'json',
    async: false,
    data: JSON.stringify({'cmd': 'show'}),
    success: function(data) {
      console.log(data.data);
      data.data.forEach(function(e) {
        types_str += '<option>' + e.type + '</option>';
      })
    },
    error: function(xhr, error_msg, error_thrown) {
      console.log(
          '[' + error_msg + ' ' + xhr.status + ']' +
          ' : ' + xhr.getResponseHeader('content-type'));
      alert(
          '[' + error_msg + ' ' + xhr.status + ']' +
          ' : ' + xhr.getResponseHeader('content-type'));
    }
  });
  return types_str;
}

function addColumn(index) {
  var column_str = new String();
  column_str += '<br><div class="row">' +
      '<label class="control-label col-md-1 col-md-offset-1">字段' + index +
      ':</label>' +
      '<label class="control-label col-md-1" for="column_name_' + index +
      '">字段名</label>' +
      '<div class="col-md-2"><input type="text" class="form-control" id="column_name_' +
      index + '" value=""></div>' +
      '<label class="control-label col-md-1" for="column_type_' + index +
      '">字段类型</label>' +
      '<div class="col-md-2"><select id="column_type_' + index +
      '" class="form-control">' + getTypes() + '</select></div>' +
      '<div class="checkbox col-md-2"><label><input type="checkbox" id="relationable_' +
      index + '"> 设为外键</label></div>' +
      '</div><div class="row" id="column_rela_' + index +
      '" style="display: none;" >' +
      '<label class="control-label col-md-2 col-md-offset-1" for="table_name">关联数据表</label>' +
      '<div class="col-md-2"><select id="rela_table_' + index +
      '" class="form-control">' + getTables() + '</select></div>';
  $('#column_' + index).html(column_str);
}

// function addRelaTable(index) {
//   var rela_table_str = new String();
//   rela_table_str +=
//       '<label class="control-label col-md-2 col-md-offset-1"
//       for="table_name">关联数据表</label>' +
//       '<div class="col-md-2"><select id="table_select" class="form-control">'
//       +
//       getTables() + '</select></div>';
//   $('#column_rela_' + index).html(rela_table_str);
// }

var ButtonInit = function() {
  var oInit = new Object();

  oInit.Init = function() {
    var column_index = 2;
    $('#btn_add_column').click(function() {
      addColumn(column_index);
      var old_column_index = column_index;
      column_index++;
      $('#relationable_' + old_column_index).change(function() {
        console.log(old_column_index);
        if ($(this).is(':checked')) {
          $('#column_rela_' + old_column_index).show();
        } else {
          $('#column_rela_' + old_column_index).hide();
        }
      });
    });

    $('#btn_create').click(function() {
      var columns = new Object();
      var foreign_keys = new Object();
      for (var i = 1; i < column_index; ++i) {
        columns[$('#column_name_' + i).val()] = $('#column_type_' + i).val();
        if ($('#relationable_' + i).is(':checked')) {
          foreign_keys[$('#column_name_' + i).val()] =
              $('#rela_table_' + i).val();
        }
      }
      $.ajax({
        type: 'POST',
        url: server_host + $('#new_table_name').val(),
        dataType: 'json',
        data:
            JSON.stringify({'cmd': 'create', 'data': [columns, foreign_keys]}),
        success: function(data) {
          alert('创建数据表成功！');
          // $('#table_select').html(getTables());
          location.reload();
        },
        error: function(xhr, error_msg, error_thrown) {
          console.log(
              '[' + error_msg + ' ' + xhr.status + ']' +
              ' : ' + xhr.getResponseHeader('content-type'));
          alert(
              '[' + error_msg + ' ' + xhr.status + ']' +
              ' : ' + xhr.getResponseHeader('content-type'));
        }
      });
    });

    $('#btn_delete').click(function() { $('#dlg_delete').modal(); });

    $('#submit_delete').click(function() {
      var selected_table = $('#table_select').val();
      $.ajax({
        type: 'POST',
        url: server_host + selected_table,
        dataType: 'json',
        data: JSON.stringify({'cmd': 'drop'}),
        success: function(data) {
          alert('删除数据表成功！');
          $('#table_select').html(getTables());
        },
        error: function(xhr, error_msg, error_thrown) {
          console.log(
              '[' + error_msg + ' ' + xhr.status + ']' +
              ' : ' + xhr.getResponseHeader('content-type'));
          alert(
              '[' + error_msg + ' ' + xhr.status + ']' +
              ' : ' + xhr.getResponseHeader('content-type'));
        }
      });
    });
  };
  return oInit;
};