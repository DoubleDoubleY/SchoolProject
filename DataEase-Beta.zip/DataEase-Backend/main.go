package main

func main() {
	ConfigInit("./config.yaml")

	StartWebService()
}
